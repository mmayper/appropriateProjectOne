﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace accountmanager
{
    public class LogonInfo
    {
        public bool successfulLogon;
        public string accountID;
        public bool admin;
        public bool active;
    }






}